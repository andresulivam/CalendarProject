/**
 * 
 */
package br.com.cotemig.entities;

/**
 * @author andresulivam
 *
 */
public class SetterCalendar {

	public static CalendarProject settlerCalendar() {
		CalendarProject calendar = new CalendarProject();
		return calendar;
	}
}
